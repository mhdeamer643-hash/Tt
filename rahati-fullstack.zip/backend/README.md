# راحتي - Backend API

باكيند حقيقي (Node.js + Express + SQLite) لتطبيق راحتي، نسخة الزبون فقط (MVP).

## التشغيل محليًا

```bash
cd backend
cp .env.example .env
npm install
npm run seed      # تعبئة بيانات تجريبية (دمشق، حمص، الغسانية، العقربية + مطاعم)
npm start         # يشتغل على http://localhost:4000
```

للتطوير مع إعادة تشغيل تلقائية عند أي تعديل:
```bash
npm run dev
```

## المسارات (API Endpoints)

| Method | Path | وصف | يحتاج توكن؟ |
|---|---|---|---|
| POST | /api/auth/request-otp | إرسال رمز تحقق لرقم هاتف | لا |
| POST | /api/auth/verify-otp | التحقق من الرمز + تسجيل دخول | لا |
| GET | /api/cities | كل المدن المتاحة | لا |
| GET | /api/cities/:id/areas | مناطق مدينة معينة | لا |
| GET | /api/restaurants?area_id=&q= | مطاعم منطقة معينة / بحث | لا |
| GET | /api/restaurants/:id | تفاصيل مطعم مع القائمة كاملة | لا |
| POST | /api/orders | إنشاء طلب جديد | نعم |
| GET | /api/orders | سجل طلبات المستخدم | نعم |
| GET | /api/orders/:id | تفاصيل وتتبع طلب | نعم |
| POST | /api/orders/:id/advance-status | (مؤقت للتجربة) تقديم حالة الطلب للخطوة التالية | نعم |

كل الطلبات المحمية تحتاج Header:
```
Authorization: Bearer <token>
```

## قبل النشر الفعلي (Production) - مهم جدًا

هاي نسخة MVP جاهزة للتطوير والتجربة. قبل ما تنشريها لزباين حقيقيين لازم:

1. **ربط بوابة SMS حقيقية**: عدّلي `src/services/sms.js` واربطيها بمزود حقيقي (Twilio، Unifonic، أو أي مزود سوري/إقليمي)، وخلي `DEV_EXPOSE_OTP=false` بملف `.env`.
2. **تغيير `JWT_SECRET`** لقيمة عشوائية طويلة وسرية.
3. **الترقية لقاعدة بيانات production-grade** إذا توقعتي حركة كبيرة (PostgreSQL مثلًا) - بنية الجداول بـ `db.js` قابلة للنقل بسهولة لأنها SQL قياسي.
4. **بناء لوحة تحكم للإدارة** (إضافة مدن/مناطق/مطاعم، استقبال الطلبات، تغيير الحالة، تعيين مندوب) - مسار `advance-status` الحالي مؤقت للتجربة فقط ولازم يستبدل بلوحة إدارة حقيقية بصلاحيات محمية.
5. **لوحة خفيفة للمطاعم** لاستلام الطلبات وقبولها/رفضها وتحديد وقت التجهيز.
6. **استضافة السيرفر**: أي مزود Node.js (Render, Railway, VPS عادي...) - السيرفر عادي (Express) وما بحتاج إعدادات خاصة.
7. **HTTPS** إلزامي بالإنتاج.

## هيكلية المشروع

```
backend/
  src/
    index.js          # نقطة الدخول
    db.js              # الاتصال وتعريف الجداول
    seed.js             # بيانات تجريبية
    middleware/auth.js  # التحقق من تسجيل الدخول
    routes/              # auth, cities, restaurants, orders
    services/sms.js      # إرسال OTP (وهمي حاليًا)
    utils/jwt.js          # توقيع/تحقق التوكن
```
