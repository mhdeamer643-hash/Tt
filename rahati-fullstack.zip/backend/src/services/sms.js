// خدمة إرسال SMS - حاليًا وهمية (تطبع بالـ console فقط)
// عند النشر الفعلي: اربطي هذا الملف مع مزود SMS حقيقي مثل Twilio أو Unifonic أو أي مزود محلي سوري/إقليمي
// مثال لاحقًا مع Twilio:
//
// const twilio = require("twilio")(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);
// async function sendOtpSms(phone, code) {
//   await twilio.messages.create({
//     to: phone,
//     from: process.env.TWILIO_FROM_NUMBER,
//     body: `رمز التحقق الخاص بك في راحتي هو: ${code}`,
//   });
// }

async function sendOtpSms(phone, code) {
  console.log(`[SMS المحاكاة] إرسال رمز التحقق ${code} إلى ${phone}`);
  return true;
}

module.exports = { sendOtpSms };
