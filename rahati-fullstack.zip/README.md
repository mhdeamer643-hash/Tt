# راحتي - تطبيق توصيل الطعام (نسخة الزبون - MVP)

مشروع كامل: Backend حقيقي (Node.js + Express + SQLite) + Frontend تفاعلي (React + Vite).

## البدء السريع

```bash
# 1) الباكيند
cd backend
cp .env.example .env
npm install
npm run seed
npm start          # http://localhost:4000

# 2) الفرونت اند (بترمينال ثاني)
cd frontend
cp .env.example .env
npm install
npm run dev         # http://localhost:5173
```

افتحي http://localhost:5173 بالمتصفح، بتقدري تكملي كل رحلة الزبون فعليًا:
تسجيل دخول (الرمز بيظهر بالشاشة بوضع التطوير) ← اختيار المدينة/المنطقة ← تصفح مطعم ← إضافة للسلة ← Checkout مع تحديد GPS حقيقي ← تتبع الطلب ← سجل الطلبات.

## نطاق هذه النسخة (MVP)

- تطبيق للزبون فقط (لا يوجد تطبيق مندوبين أو لوحة إدارة كاملة بعد)
- الدفع نقدًا عند الاستلام فقط
- مدن الإطلاق: دمشق، حمص، الغسانية، العقربية (بيانات تجريبية بـ`npm run seed`)
- تحديد موقع التوصيل عبر GPS فقط (بدون كتابة عنوان يدوي)

## الخطوات التالية المقترحة

راجعي `backend/README.md` لقائمة كاملة بما يلزم قبل النشر الفعلي (SMS حقيقي، JWT secret، لوحة إدارة، لوحة مطاعم، استضافة).

## الهيكلية

```
rahati-fullstack/
  backend/     # Node.js + Express + SQLite - API حقيقي
  frontend/    # React + Vite - تطبيق الزبون
```
